import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Link, NavLink } from 'react-router-dom';
import { Sun, Moon, Menu, X, Zap, BadgeCheck } from 'lucide-react';
import { SiTiktok } from 'react-icons/si';
import { ROUTE_PATHS } from '@/lib/index';

interface HeaderProps {
  theme: 'light' | 'dark';
  onThemeToggle: () => void;
}

export function Header({ theme, onThemeToggle }: HeaderProps) {
  const [scrolled, setScrolled] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navLinks = [
    { to: ROUTE_PATHS.HOME, label: 'Home' },
    { to: ROUTE_PATHS.SUPPORTED, label: 'Supported' },
  ];

  const chipStyle = "flex items-center gap-2 px-3 py-1.5 rounded-full border border-white/40 dark:border-white/10 bg-white/40 dark:bg-white/5 backdrop-blur-md shadow-sm transition-all duration-200 shrink-0";

  return (
    <header
      className={`sticky top-0 z-50 w-full transition-all duration-500 ${
        scrolled
          ? 'border-b border-white/20 dark:border-white/10 shadow-lg'
          : 'border-b border-transparent'
      }`}
      style={{
        background: scrolled
          ? 'rgba(255,255,255,0.55)'
          : 'transparent',
        backdropFilter: scrolled ? 'blur(20px) saturate(180%)' : 'none',
        WebkitBackdropFilter: scrolled ? 'blur(20px) saturate(180%)' : 'none',
      }}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-14 flex items-center justify-between gap-3">
        {/* Logo Section - Two ALWAYS Visible Chips */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar scroll-smooth py-1">
          {/* Chip 1: Brand */}
          <NavLink 
            to={ROUTE_PATHS.HOME} 
            className={({ isActive }) => `${chipStyle} group ${isActive ? 'ring-1 ring-primary/30' : ''}`}
          >
            <Zap size={16} className="text-primary group-hover:scale-110 transition-transform fill-primary/10" />
            <span className="font-bold text-foreground text-[11px] uppercase tracking-wider whitespace-nowrap">innks bypass</span>
          </NavLink>

          {/* Chip 2: Author Badge (@unklir) - Link to TikTok */}
          <a 
            href="https://www.tiktok.com/@unklir" 
            target="_blank" 
            rel="noopener noreferrer" 
            className={`${chipStyle} hover:bg-white/60 dark:hover:bg-white/10`}
          >
            <span className="text-[10px] font-bold text-muted-foreground uppercase tracking-tight whitespace-nowrap">by @unklir</span>
            <div className="flex items-center gap-1.5 border-l border-white/30 dark:border-white/10 pl-1.5">
              {/* Instagram-style Verification Badge */}
              <BadgeCheck size={14} className="text-[#0095F6] fill-[#0095F6]/10" />
              {/* TikTok Icon */}
              <SiTiktok size={11} className="text-foreground/80" />
            </div>
          </a>
        </div>

        {/* Right Icons */}
        <div className="flex items-center gap-1 shrink-0">
          {/* Desktop Nav Links */}
          <nav className="hidden md:flex items-center gap-1 mr-2">
            {navLinks.map(({ to, label }) => (
              <NavLink
                key={to}
                to={to}
                className={({ isActive }) =>
                  `px-3 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    isActive
                      ? 'bg-white/60 dark:bg-white/10 text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground'
                  }`
                }
              >
                {label}
              </NavLink>
            ))}
          </nav>

          {/* Theme toggle */}
          <button
            onClick={onThemeToggle}
            className="w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/50 dark:hover:bg-white/10 transition-all duration-200 border border-transparent hover:border-white/30 dark:hover:border-white/10"
          >
            <AnimatePresence mode="wait" initial={false}>
              <motion.span
                key={theme}
                initial={{ opacity: 0, rotate: -90, scale: 0.7 }}
                animate={{ opacity: 1, rotate: 0, scale: 1 }}
                exit={{ opacity: 0, rotate: 90, scale: 0.7 }}
                transition={{ duration: 0.18 }}
              >
                {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
              </motion.span>
            </AnimatePresence>
          </button>

          {/* Mobile Menu Button */}
          <button
            className="md:hidden w-8 h-8 flex items-center justify-center rounded-lg text-muted-foreground hover:text-foreground hover:bg-white/50 dark:hover:bg-white/10 transition-all duration-200"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X size={16} /> : <Menu size={16} />}
          </button>
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.22 }}
            className="md:hidden overflow-hidden border-t border-white/20 dark:border-white/10"
            style={{
              background: 'rgba(255,255,255,0.65)',
              backdropFilter: 'blur(20px) saturate(180%)',
              WebkitBackdropFilter: 'blur(20px) saturate(180%)',
            }}
          >
            <nav className="px-4 py-3 flex flex-col gap-1">
              {navLinks.map(({ to, label }) => (
                <NavLink
                  key={to}
                  to={to}
                  onClick={() => setMobileMenuOpen(false)}
                  className={({ isActive }) =>
                    `px-3 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive
                        ? 'bg-white/70 dark:bg-white/10 text-foreground'
                        : 'text-muted-foreground hover:text-foreground hover:bg-white/50 dark:hover:bg-white/8'
                    }`
                  }
                >
                  {label}
                </NavLink>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}

export function Footer() {
  return (
    <footer
      className="border-t border-white/30 dark:border-white/10 mt-auto"
      style={{
        background: 'rgba(255,255,255,0.45)',
        backdropFilter: 'blur(16px) saturate(160%)',
        WebkitBackdropFilter: 'blur(16px) saturate(160%)',
      }}
    >
      <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col items-center gap-6">
        <div className="flex flex-col items-center gap-3 text-center">
          <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-[0.15em] opacity-80 max-w-xs leading-relaxed">
            UI/UX design inspired by izen.lol • Credits to the original creators
          </p>
          <div className="w-12 h-[1px] bg-white/20 dark:bg-white/10" />
          <span className="text-xs text-foreground font-bold tracking-wider uppercase">innks bypass © 2026</span>
        </div>
        
        <nav className="flex items-center gap-8">
          {[
            { to: ROUTE_PATHS.HOME, label: 'Home' },
            { to: ROUTE_PATHS.TERMS, label: 'Terms' },
            { to: ROUTE_PATHS.PRIVACY, label: 'Privacy' },
          ].map(({ to, label }) => (
            <Link
              key={to}
              to={to}
              className="text-xs text-muted-foreground hover:text-foreground transition-all duration-200"
            >
              {label}
            </Link>
          ))}
        </nav>
      </div>
    </footer>
  );
}
