import { useState, useEffect } from 'react';
import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import { Header, Footer } from '@/components/Layout';
import { ROUTE_PATHS } from '@/lib/index';
import Home from '@/pages/Home';
import Supported from '@/pages/Supported';
import Terms from '@/pages/Terms';
import Privacy from '@/pages/Privacy';

function App() {
  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    try {
      if (typeof window === 'undefined') return 'light';
      const saved = localStorage.getItem('innk-theme');
      if (saved === 'dark' || saved === 'light') return saved;
      return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
    } catch (e) {
      // Return default if localStorage is blocked (e.g. SecurityError)
      return 'light';
    }
  });

  useEffect(() => {
    try {
      const root = document.documentElement;
      if (theme === 'dark') {
        root.classList.add('dark');
      } else {
        root.classList.remove('dark');
      }
      localStorage.setItem('innk-theme', theme);
    } catch (e) {
      // Ignore errors during setting (e.g. localStorage blocked)
    }
  }, [theme]);

  const toggleTheme = () => setTheme((t) => (t === 'dark' ? 'light' : 'dark'));

  return (
    <Router>
      <div className="flex flex-col min-h-screen bg-background transition-colors duration-300">
        <Header theme={theme} onThemeToggle={toggleTheme} />
        <main className="flex-1">
          <Routes>
            <Route path={ROUTE_PATHS.HOME} element={<Home />} />
            <Route path={ROUTE_PATHS.SUPPORTED} element={<Supported />} />
            <Route path={ROUTE_PATHS.TERMS} element={<Terms />} />
            <Route path={ROUTE_PATHS.PRIVACY} element={<Privacy />} />
            {/* Catch-all route to redirect back to home if needed */}
            <Route path="*" element={<Home />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </Router>
  );
}

export default App;
