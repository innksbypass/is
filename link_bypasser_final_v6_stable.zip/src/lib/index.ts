// Route constants
export const ROUTE_PATHS = {
  HOME: '/',
  SUPPORTED: '/supported',
  TERMS: '/terms',
  PRIVACY: '/privacy',
};

// --- Dynamic "months of service" ---
// Starts at 0 from current date (March 2026)
const LAUNCH_DATE = new Date('2026-03-01T00:00:00Z');
export function getMonthsOfService(): number {
  const now = new Date();
  const months =
    (now.getFullYear() - LAUNCH_DATE.getFullYear()) * 12 +
    (now.getMonth() - LAUNCH_DATE.getMonth());
  return Math.max(0, months);
}

// --- "Links bypassed" counter stored in localStorage ---
export function getBypassCount(): number {
  return parseInt(localStorage.getItem('innk_bypass_count') || '0', 10);
}
export function incrementBypassCount(): number {
  const next = getBypassCount() + 1;
  localStorage.setItem('innk_bypass_count', String(next));
  return next;
}

// Types
export interface Service {
  name: string;
  icon: string;
  status: 'active' | 'beta' | 'new';
}

export interface StepItem {
  number: number;
  title: string;
  description: string;
  color: string;
}

export interface FeatureItem {
  icon: string;
  title: string;
  description: string;
  color: string;
}

// 5 real supported services only
export const SUPPORTED_SERVICES: Service[] = [
  { name: 'Platoboost', icon: '🚀', status: 'active' },
  { name: 'Work.ink',   icon: '✍️', status: 'active' },
  { name: 'Linkvertise',icon: '🔗', status: 'active' },
  { name: 'Admaven (Lootlabs)', icon: '💰', status: 'active' },
  { name: 'Rekonise',   icon: '🔑', status: 'active' },
];

// URL patterns per service
export const SERVICE_PATTERNS: { name: string; pattern: RegExp; hint: string }[] = [
  {
    name: 'Platoboost',
    pattern: /platoboost\.com/i,
    hint: 'e.g. https://platoboost.com/redirect/?id=...',
  },
  {
    name: 'Work.ink',
    pattern: /work\.ink/i,
    hint: 'e.g. https://work.ink/...',
  },
  {
    name: 'Linkvertise',
    pattern: /linkvertise\.com|link-to\.net|linkv\.gg|up-to-down\.net/i,
    hint: 'e.g. https://linkvertise.com/...',
  },
  {
    name: 'Admaven / Lootlabs',
    pattern: /loot-link\.com|lootlabs\.gg|loots\.gg|admaven\.com/i,
    hint: 'e.g. https://loot-link.com/s?...',
  },
  {
    name: 'Rekonise',
    pattern: /rekonise\.com/i,
    hint: 'e.g. https://rekonise.com/...',
  },
];

export function detectService(url: string): { name: string; hint: string } | null {
  for (const s of SERVICE_PATTERNS) {
    if (s.pattern.test(url)) return { name: s.name, hint: s.hint };
  }
  return null;
}

export const STEPS: StepItem[] = [
  {
    number: 1,
    title: 'Paste Your Link',
    description:
      'Copy and paste a Platoboost, Work.ink, Linkvertise, Lootlabs or Rekonise URL into the input field.',
    color: 'from-orange-400 to-orange-500',
  },
  {
    number: 2,
    title: 'Verify Captcha',
    description:
      'Click the checkbox to confirm you are human. One simple click — no puzzles needed.',
    color: 'from-blue-400 to-blue-500',
  },
  {
    number: 3,
    title: 'Get Results',
    description:
      'Receive your bypassed link instantly. Copy or open the result with one click.',
    color: 'from-teal-400 to-teal-500',
  },
];

export const FEATURES: FeatureItem[] = [
  {
    icon: '🆓',
    title: '100% Free',
    description:
      'Bypasses for Platoboost, Work.ink, Linkvertise, Lootlabs (Admaven) and Rekonise — always free.',
    color: 'text-teal-500',
  },
  {
    icon: '⚡',
    title: 'Lightning Fast',
    description:
      'Optimized pipeline delivers results in seconds for all 5 supported services.',
    color: 'text-blue-500',
  },
  {
    icon: '🔐',
    title: 'Secure & Private',
    description:
      "Your privacy matters. We don't store your links or track your activity.",
    color: 'text-purple-500',
  },
];
