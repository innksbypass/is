import { motion } from 'framer-motion';

export default function Terms() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-6"
      >
        <h1 className="text-3xl font-bold text-foreground">Terms of Service</h1>
        <p className="text-muted-foreground text-sm">Last updated: January 2026</p>
        {[
          { title: '1. Acceptance of Terms', body: 'By accessing and using innk bypass ("Service"), you accept and agree to be bound by the terms and provisions of this agreement. The Service provides link bypass functionality for supported URL shorteners and content lockers.' },
          { title: '2. Use of Service', body: 'You agree to use the Service only for lawful purposes and in a way that does not infringe the rights of others. You must not misuse our Service by knowingly introducing viruses, trojans, worms, or other material that is malicious or technologically harmful.' },
          { title: '3. Disclaimer', body: 'The Service is provided "as is" without warranty of any kind. We do not guarantee uninterrupted or error-free service. Advertisements displayed on the Service help keep it free and running.' },
          { title: '4. Limitation of Liability', body: 'In no event shall innk bypass be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the Service.' },
          { title: '5. Changes to Terms', body: 'We reserve the right to modify these Terms at any time. Changes will be effective upon posting to the website. Your continued use of the Service constitutes your acceptance of the modified Terms.' },
        ].map((section) => (
          <div key={section.title} className="space-y-2">
            <h2 className="text-base font-semibold text-foreground">{section.title}</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">{section.body}</p>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
