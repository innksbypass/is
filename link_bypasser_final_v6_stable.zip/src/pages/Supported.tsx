import { useEffect, useState } from 'react';
import { motion } from 'framer-motion';
import { CheckCircle2 } from 'lucide-react';
import { SUPPORTED_SERVICES } from '@/lib/index';

const statusColors: Record<string, string> = {
  active:  'bg-teal-100 text-teal-700 dark:bg-teal-900/30 dark:text-teal-400',
  beta:    'bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400',
  new:     'bg-orange-100 text-orange-700 dark:bg-orange-900/30 dark:text-orange-400',
};

const glassCard: React.CSSProperties = {
  background: 'rgba(255,255,255,0.55)',
  backdropFilter: 'blur(18px) saturate(180%)',
  WebkitBackdropFilter: 'blur(18px) saturate(180%)',
  border: '1px solid rgba(255,255,255,0.45)',
  boxShadow: '0 4px 24px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.7)',
};

export default function Supported() {
  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-12">
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }} className="mb-10 text-center">
        <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium text-muted-foreground mb-4"
          style={{ background: 'rgba(255,255,255,0.5)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.4)' }}>
          <CheckCircle2 size={12} className="text-teal-500" />
          SUPPORTED SERVICES
        </span>
        <h1 className="text-3xl sm:text-4xl font-bold text-foreground mb-3">Supported Services</h1>
        <p className="text-muted-foreground text-sm max-w-lg mx-auto mb-3">
          All services currently supported by innks bypass.
        </p>
      </motion.div>

      <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3">
        {SUPPORTED_SERVICES.map((svc, i) => (
          <motion.div key={svc.name}
            initial={{ opacity: 0, y: 12 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.04 }} whileHover={{ y: -2, scale: 1.02 }}
            className="rounded-xl p-4 flex items-center gap-3 transition-all"
            style={glassCard}>
            <span className="text-2xl">{svc.icon}</span>
            <div className="flex-1 min-w-0">
              <p className="font-medium text-sm text-foreground truncate">{svc.name}</p>
              <span className={`inline-block text-xs px-1.5 py-0.5 rounded-full font-medium ${statusColors[svc.status]}`}>
                {svc.status}
              </span>
            </div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  );
}
