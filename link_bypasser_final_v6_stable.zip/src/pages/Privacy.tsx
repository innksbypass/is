import { motion } from 'framer-motion';

export default function Privacy() {
  return (
    <div className="max-w-3xl mx-auto px-4 sm:px-6 py-12">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="space-y-6"
      >
        <h1 className="text-3xl font-bold text-foreground">Privacy Policy</h1>
        <p className="text-muted-foreground text-sm">Last updated: January 2026</p>
        {[
          { title: 'Information We Collect', body: 'innk bypass does not store the URLs you submit for bypassing. We may collect anonymous usage statistics (number of bypasses, service types) to improve the platform. No personally identifiable information is collected.' },
          { title: 'Cookies & Tracking', body: 'We use minimal cookies necessary for site functionality such as theme preferences. Third-party advertisements may use their own cookies; we have no control over these.' },
          { title: 'Data Retention', body: 'Since we do not store your submitted URLs, there is no link data to delete. Anonymous analytics are retained for a maximum of 90 days.' },
          { title: 'Third-Party Services', body: 'Our site may display advertisements served by third parties. These services have their own privacy policies. We recommend reviewing those policies.' },
          { title: 'Contact', body: 'If you have any questions about this Privacy Policy, please contact us at contact@innk bypass.' },
        ].map((section) => (
          <div key={section.title} className="space-y-2">
            <h2 className="text-base font-semibold text-foreground">{section.title}</h2>
            <p className="text-muted-foreground text-sm leading-relaxed">{section.body}</p>
          </div>
        ))}
      </motion.div>
    </div>
  );
}
