import { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Copy, ExternalLink, AlertCircle, Loader2, ArrowRight,
  CheckCircle2, ShieldCheck, XCircle,
} from 'lucide-react';
import {
  STEPS, FEATURES,
  detectService, getBypassCount, incrementBypassCount, getMonthsOfService,
} from '@/lib/index';

// ─── helpers ────────────────────────────────────────────────────────────────

const glassCard: React.CSSProperties = {
  background: 'rgba(255,255,255,0.55)',
  backdropFilter: 'blur(18px) saturate(180%)',
  WebkitBackdropFilter: 'blur(18px) saturate(180%)',
  border: '1px solid rgba(255,255,255,0.45)',
  boxShadow: '0 4px 24px rgba(0,0,0,0.06), inset 0 1px 0 rgba(255,255,255,0.7)',
};

const fadeInUp = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.4, ease: [0.25, 0.46, 0.45, 0.94] },
};
const staggerContainer = { animate: { transition: { staggerChildren: 0.08 } } };

// Real bypass via bypass.bot.nu (free, no key needed)
async function callBypassAPI(url: string): Promise<string> {
  // Primary: bypass.bot.nu
  const proxyBase = 'https://api.allorigins.win/get?url=';
  const targetEnc = encodeURIComponent(`https://bypass.bot.nu/bypass2?url=${encodeURIComponent(url)}`);

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 15000);

  try {
    const r = await fetch(proxyBase + targetEnc, { signal: controller.signal });
    clearTimeout(timeoutId);
    
    if (!r.ok) throw new Error('proxy error');
    const wrapper = await r.json() as { contents?: string };
    const contents = wrapper.contents;
    if (!contents) throw new Error('empty');

    const parsed = JSON.parse(contents) as { destination?: string; result?: string };
    const result = parsed.destination || parsed.result;
    if (!result || result === url) throw new Error('bypass failed');
    return result;
  } catch (err) {
    clearTimeout(timeoutId);
    throw err;
  }
}

// ─── Captcha component ───────────────────────────────────────────────────────
function CaptchaBox({ onVerified }: { onVerified: () => void }) {
  const [state, setState] = useState<'idle' | 'checking' | 'done'>('idle');

  const handleClick = () => {
    if (state !== 'idle') return;
    setState('checking');
    setTimeout(() => {
      setState('done');
      setTimeout(onVerified, 400);
    }, 900);
  };

  return (
    <div className="rounded-xl p-4 flex items-center justify-between gap-4"
      style={{ background: 'rgba(255,255,255,0.45)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.4)' }}>
      <div>
        <p className="text-sm font-medium text-foreground">I'm not a robot</p>
        <p className="text-xs text-muted-foreground mt-0.5">reCAPTCHA — Privacy · Terms</p>
      </div>
      <button
        onClick={handleClick}
        disabled={state !== 'idle'}
        className="w-9 h-9 rounded-md border-2 flex items-center justify-center transition-all duration-300 shrink-0"
        style={{
          borderColor: state === 'done' ? 'oklch(0.55 0.14 180)' : 'rgba(0,0,0,0.2)',
          background: state === 'done' ? 'oklch(0.55 0.14 180 / 0.12)' : 'white',
        }}
      >
        <AnimatePresence mode="wait">
          {state === 'idle' && <motion.span key="idle" initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="w-3 h-3 rounded-sm border-2 border-gray-300 block" />}
          {state === 'checking' && <motion.span key="check" initial={{ opacity: 0 }} animate={{ opacity: 1 }}><Loader2 size={16} className="animate-spin text-muted-foreground" /></motion.span>}
          {state === 'done' && <motion.span key="done" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: 'spring', stiffness: 500, damping: 25 }}><CheckCircle2 size={20} className="text-teal-500" /></motion.span>}
        </AnimatePresence>
      </button>
    </div>
  );
}

// ─── Main bypass hero ────────────────────────────────────────────────────────
function BypassHero() {
  const [url, setUrl]             = useState('');
  const [detected, setDetected]   = useState<{ name: string; hint: string } | null>(null);
  const [urlError, setUrlError]   = useState('');
  const [captchaDone, setCaptchaDone] = useState(false);
  const [showCaptcha, setShowCaptcha] = useState(false);
  const [result, setResult]       = useState('');
  const [loading, setLoading]     = useState(false);
  const [apiError, setApiError]   = useState('');
  const [copied, setCopied]       = useState(false);
  const [bypassCount, setBypassCount] = useState(getBypassCount);

  // Detect service while typing
  const handleUrlChange = (val: string) => {
    setUrl(val);
    setUrlError('');
    setResult('');
    setApiError('');
    setCaptchaDone(false);
    setShowCaptcha(false);
    if (val.trim()) {
      setDetected(detectService(val.trim()));
    } else {
      setDetected(null);
    }
  };

  const handleVerifyClick = () => {
    if (!url.trim()) { setUrlError('Please enter a URL first.'); return; }
    if (!detected) {
      setUrlError('Unsupported URL. Accepted: Platoboost, Work.ink, Linkvertise, Lootlabs, Rekonise.');
      return;
    }
    setShowCaptcha(true);
  };

  const handleBypass = async () => {
    setLoading(true);
    setApiError('');
    setResult('');
    try {
      const res = await callBypassAPI(url.trim());
      setResult(res);
      const next = incrementBypassCount();
      setBypassCount(next);
    } catch (e) {
      const msg = e instanceof Error ? e.message : 'unknown';
      setApiError(`Bypass failed (${msg}). The service may be temporarily unavailable.`);
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <section className="relative pt-16 pb-10 overflow-hidden">
      {/* Orbs */}
      <div aria-hidden className="absolute -top-40 -left-40 w-[500px] h-[500px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, oklch(0.68 0.12 240 / 0.35), transparent 65%)' }} />
      <div aria-hidden className="absolute top-0 right-0 w-[380px] h-[380px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, oklch(0.70 0.18 30 / 0.2), transparent 65%)' }} />
      <div aria-hidden className="absolute bottom-0 left-1/2 -translate-x-1/2 w-[600px] h-[200px] rounded-full pointer-events-none"
        style={{ background: 'radial-gradient(circle, oklch(0.65 0.14 270 / 0.12), transparent 70%)' }} />

      <div className="max-w-6xl mx-auto px-4 sm:px-6 relative z-10">
        <div className="grid lg:grid-cols-2 gap-10 lg:gap-16 items-start">
          {/* Left */}
          <motion.div variants={staggerContainer} initial="initial" animate="animate" className="space-y-5">
            <motion.div variants={fadeInUp}>
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium text-muted-foreground"
                style={{ background: 'rgba(255,255,255,0.5)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.4)' }}>
                <span className="w-1.5 h-1.5 rounded-full bg-teal-500 animate-pulse" />
                innks bypass
              </span>
            </motion.div>

            <motion.div variants={fadeInUp}>
              <h1 className="text-5xl sm:text-6xl font-bold text-foreground tracking-tight leading-none">Bypass</h1>
            </motion.div>

            <motion.p variants={fadeInUp} className="text-muted-foreground text-base leading-relaxed max-w-md">
              Paste a supported URL, verify once, and get your result in seconds. Supports Platoboost, Work.ink, Linkvertise, Admaven (Lootlabs) and Rekonise.
            </motion.p>

            <motion.div variants={fadeInUp}>
              <div className="flex items-start gap-3 px-4 py-3 rounded-xl"
                style={{ background: 'rgba(254,243,199,0.6)', backdropFilter: 'blur(12px)', border: '1px solid rgba(253,224,130,0.5)' }}>
                <AlertCircle size={15} className="text-amber-600 mt-0.5 shrink-0" />
                <p className="text-xs text-amber-700 dark:text-amber-400 leading-relaxed">
                  This site is not infected with any virus. Advertisements are used to support the project and help keep it running.
                </p>
              </div>
            </motion.div>

            {/* Live bypass counter */}
            <motion.div variants={fadeInUp}>
              <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs text-muted-foreground"
                style={{ background: 'rgba(255,255,255,0.45)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.4)' }}>
                <ShieldCheck size={12} className="text-teal-500" />
                <span><strong className="text-foreground">{bypassCount.toLocaleString()}</strong> links bypassed in this session</span>
              </div>
            </motion.div>
          </motion.div>

          {/* Right — Glass card */}
          <motion.div initial={{ opacity: 0, y: 24 }} animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.15, duration: 0.5 }}>
            <div className="rounded-2xl p-6 space-y-4" style={glassCard}>

              {/* URL input */}
              <div>
                <label className="text-xs font-medium text-muted-foreground mb-2 block">Input your URL</label>
                <input type="url" value={url}
                  onChange={(e) => handleUrlChange(e.target.value)}
                  placeholder="Paste a Platoboost, Work.ink, Linkvertise... URL"
                  className="w-full px-3 py-2.5 rounded-lg text-sm text-foreground placeholder:text-muted-foreground/50 focus:outline-none focus:ring-2 focus:ring-ring transition-all"
                  style={{ background: 'rgba(255,255,255,0.6)', border: '1px solid rgba(255,255,255,0.5)', backdropFilter: 'blur(8px)' }}
                />
                <div className="flex items-center justify-between mt-1.5 min-h-[18px]">
                  {urlError
                    ? <p className="text-xs text-destructive flex items-center gap-1"><XCircle size={11} />{urlError}</p>
                    : detected
                      ? <p className="text-xs text-teal-600 dark:text-teal-400 flex items-center gap-1"><CheckCircle2 size={11} />Detected: <strong>{detected.name}</strong></p>
                      : url.trim()
                        ? <p className="text-xs text-muted-foreground/60">{detected === null ? 'Unsupported service' : 'Enter a URL'}</p>
                        : <span className="text-xs text-muted-foreground/50">Paste one supported URL to begin.</span>
                  }
                  <button className="text-xs text-muted-foreground hover:text-foreground transition-colors shrink-0">Single link</button>
                </div>
              </div>

              {/* Captcha (shown after clicking Verify) */}
              <AnimatePresence>
                {showCaptcha && !captchaDone && (
                  <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: 'auto' }}
                    exit={{ opacity: 0, height: 0 }} transition={{ duration: 0.2 }}>
                    <CaptchaBox onVerified={() => setCaptchaDone(true)} />
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Action button */}
              {!captchaDone ? (
                <button onClick={handleVerifyClick}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 active:scale-[0.98] transition-all"
                  style={{ boxShadow: '0 4px 14px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.12)' }}>
                  Verify & Bypass
                  <ArrowRight size={15} />
                </button>
              ) : (
                <button onClick={handleBypass} disabled={loading}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-primary text-primary-foreground text-sm font-medium hover:opacity-90 active:scale-[0.98] transition-all disabled:opacity-60"
                  style={{ boxShadow: '0 4px 14px rgba(0,0,0,0.18), inset 0 1px 0 rgba(255,255,255,0.12)' }}>
                  {loading ? (<><Loader2 size={15} className="animate-spin" />Bypassing...</>) : (<>Bypass Now<ArrowRight size={15} /></>)}
                </button>
              )}

              {/* Error */}
              <AnimatePresence>
                {apiError && (
                  <motion.div initial={{ opacity: 0, y: 4 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0 }}
                    className="flex items-start gap-2 p-3 rounded-lg bg-red-50 dark:bg-red-950/30 border border-red-200 dark:border-red-800/40">
                    <XCircle size={14} className="text-destructive mt-0.5 shrink-0" />
                    <p className="text-xs text-destructive leading-relaxed">{apiError}</p>
                  </motion.div>
                )}
              </AnimatePresence>

              {/* Result */}
              <AnimatePresence>
                {result && (
                  <motion.div initial={{ opacity: 0, y: 8 }} animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }} className="p-3 rounded-lg space-y-2"
                    style={{ background: 'rgba(255,255,255,0.45)', backdropFilter: 'blur(10px)', border: '1px solid rgba(255,255,255,0.4)' }}>
                    <div className="flex items-center gap-1 mb-1">
                      <CheckCircle2 size={13} className="text-teal-500" />
                      <p className="text-xs font-medium text-teal-600 dark:text-teal-400">Bypassed successfully!</p>
                    </div>
                    <div className="flex items-center gap-2">
                      <p className="flex-1 text-xs text-foreground font-mono truncate">{result}</p>
                      <button onClick={handleCopy}
                        className="p-1.5 rounded-md hover:bg-white/60 text-muted-foreground hover:text-foreground transition-colors">
                        <Copy size={13} />
                      </button>
                      <a href={result} target="_blank" rel="noopener noreferrer"
                        className="p-1.5 rounded-md hover:bg-white/60 text-muted-foreground hover:text-foreground transition-colors">
                        <ExternalLink size={13} />
                      </a>
                    </div>
                    {copied && <p className="text-xs text-teal-600 dark:text-teal-400">✓ Copied to clipboard!</p>}
                  </motion.div>
                )}
              </AnimatePresence>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ─── Status cards ───────────────────────────────────────────────────────────
function StatusCards() {
  const cards = [
    { label: 'STATUS',   title: 'Live + Stable', desc: 'Realtime health checks and fast recovery.', dot: 'bg-teal-500' },
    { label: 'COVERAGE', title: '5 Services',     desc: 'Platoboost, Work.ink, Linkvertise, Lootlabs, Rekonise.', dot: 'bg-blue-500' },
    { label: 'SPEED',    title: 'Low Latency',   desc: 'Optimized pipeline for fast results.', dot: 'bg-purple-500' },
  ];
  return (
    <section className="py-6">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div variants={staggerContainer} initial="initial" whileInView="animate" viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          {cards.map((c) => (
            <motion.div key={c.label} variants={fadeInUp} whileHover={{ y: -3, scale: 1.01 }}
              className="rounded-xl p-4 transition-all" style={glassCard}>
              <div className="flex items-center gap-2 mb-2">
                <span className={`w-1.5 h-1.5 rounded-full ${c.dot}`} />
                <span className="text-xs font-semibold text-muted-foreground tracking-wider">{c.label}</span>
              </div>
              <p className="font-semibold text-foreground text-sm mb-1">{c.title}</p>
              <p className="text-xs text-muted-foreground">{c.desc}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ─── How It Works ────────────────────────────────────────────────────────────
function HowItWorks() {
  return (
    <section className="py-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <div className="rounded-2xl p-8 sm:p-12" style={glassCard}>
          <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
            transition={{ duration: 0.4 }} className="text-center mb-10">
            <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">How It Works</h2>
            <p className="text-muted-foreground text-sm">Three simple steps to bypass any link</p>
          </motion.div>
          <motion.div variants={staggerContainer} initial="initial" whileInView="animate" viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-3 gap-8">
            {STEPS.map((step) => (
              <motion.div key={step.number} variants={fadeInUp} className="text-center space-y-3">
                <div className={`w-10 h-10 rounded-xl bg-gradient-to-br ${step.color} flex items-center justify-center text-white font-bold text-base mx-auto`}
                  style={{ boxShadow: '0 4px 14px rgba(0,0,0,0.15)' }}>
                  {step.number}
                </div>
                <h3 className="font-semibold text-foreground text-sm">{step.title}</h3>
                <p className="text-muted-foreground text-xs leading-relaxed">{step.description}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </section>
  );
}

// ─── Why Choose ─────────────────────────────────────────────────────────────
function WhyChooseInnk() {
  return (
    <section className="py-10">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }}
          transition={{ duration: 0.4 }} className="text-center mb-10">
          <h2 className="text-2xl sm:text-3xl font-bold text-foreground mb-2">Why Choose innk?</h2>
          <p className="text-muted-foreground text-sm">Fast, reliable, and completely free</p>
        </motion.div>
        <motion.div variants={staggerContainer} initial="initial" whileInView="animate" viewport={{ once: true }}
          className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {FEATURES.map((f) => (
            <motion.div key={f.title} variants={fadeInUp} whileHover={{ y: -4, scale: 1.02 }}
              className="rounded-2xl p-6 text-center space-y-3 transition-all"
              style={{ ...glassCard, boxShadow: '0 8px 32px rgba(0,0,0,0.07), inset 0 1px 0 rgba(255,255,255,0.7)' }}>
              <div className="w-12 h-12 rounded-2xl flex items-center justify-center text-2xl mx-auto"
                style={{ background: 'rgba(255,255,255,0.6)', backdropFilter: 'blur(8px)', border: '1px solid rgba(255,255,255,0.5)' }}>
                {f.icon}
              </div>
              <h3 className="font-semibold text-foreground text-sm">{f.title}</h3>
              <p className="text-muted-foreground text-xs leading-relaxed">{f.description}</p>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}

// ─── Stats ───────────────────────────────────────────────────────────────────
function StatsSection() {
  const [count, setCount] = useState(getBypassCount);
  const months = getMonthsOfService();

  // Refresh count every 3 seconds in case another tab updated it
  useEffect(() => {
    const id = setInterval(() => setCount(getBypassCount()), 3000);
    return () => clearInterval(id);
  }, []);

  const stats = [
    { value: count.toLocaleString(), label: 'Links Bypassed' },
    { value: '5',                     label: 'Supported Services' },
    { value: `${months} month${months !== 1 ? 's' : ''}`, label: 'Of Service' },
  ];

  return (
    <section className="py-6 pb-16">
      <div className="max-w-6xl mx-auto px-4 sm:px-6">
        <motion.div initial={{ opacity: 0, y: 16 }} whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }} transition={{ duration: 0.4 }}
          className="rounded-2xl p-8" style={glassCard}>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 text-center">
            {stats.map((s, i) => (
              <motion.div key={s.label} initial={{ opacity: 0, y: 12 }} whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }} transition={{ delay: i * 0.1, duration: 0.4 }}>
                <p className="text-3xl sm:text-4xl font-bold text-foreground mb-1">{s.value}</p>
                <p className="text-sm text-muted-foreground">{s.label}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
}

// ─── Page export ─────────────────────────────────────────────────────────────
export default function Home() {
  return (
    <div className="min-h-screen">
      <BypassHero />
      <StatusCards />
      <HowItWorks />
      <WhyChooseInnk />
      <StatsSection />
    </div>
  );
}
